"""
config.py
Centralised settings via pydantic-settings.
All values can be overridden by environment variables or a .env file.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    frontend_url: str = "http://localhost:3000"
    secret_key: str = "change-me-in-production"
    debug: bool = False

    # LLM
    anthropic_api_key: str = ""

    # Observability
    langchain_api_key: str = ""
    langchain_tracing_v2: str = "true"
    langchain_project: str = "candidates-fte"
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host: str = "https://cloud.langfuse.com"

    # External APIs
    apify_api_key: str = ""
    hunter_io_api_key: str = ""

    # Gmail OAuth2
    gmail_client_id: str = ""
    gmail_client_secret: str = ""
    gmail_redirect_uri: str = "http://localhost:8000/auth/gmail/callback"

    # Database
    postgres_url: str = "postgresql+asyncpg://postgres:password@localhost:5432/candidates_fte"
    redis_url: str = "redis://localhost:6379/0"

    # Agent tuning
    max_jobs_per_search: int = 50
    max_cvs_to_tailor: int = 10
    hitl_timeout_minutes: int = 60


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
