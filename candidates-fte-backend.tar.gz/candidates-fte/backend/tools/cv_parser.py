"""
tools/cv_parser.py
Parse uploaded CVs (PDF/DOCX) and extract structured information.
"""
import io
import re
from typing import Any
import pdfplumber
import structlog
from docx import Document as DocxDocument

log = structlog.get_logger()


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract text from a PDF file."""
    text = ""
    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n\n"
    return text.strip()


def extract_text_from_docx(file_bytes: bytes) -> str:
    """Extract text from a DOCX file."""
    doc = DocxDocument(io.BytesIO(file_bytes))
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    return "\n\n".join(paragraphs)


def extract_text_from_file(file_bytes: bytes, filename: str) -> str:
    """Auto-detect file type and extract text."""
    filename_lower = filename.lower()
    if filename_lower.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)
    elif filename_lower.endswith(".docx"):
        return extract_text_from_docx(file_bytes)
    elif filename_lower.endswith(".txt"):
        return file_bytes.decode("utf-8", errors="ignore")
    else:
        raise ValueError(f"Unsupported file type: {filename}")


def parse_cv_sections(raw_text: str) -> dict[str, str]:
    """
    Attempt to split a CV into logical sections.
    Returns dict like: {"summary": ..., "experience": ..., "education": ..., "skills": ...}
    """
    section_headers = {
        "summary": r"(summary|profile|objective|about me)",
        "experience": r"(experience|work history|employment|career history)",
        "education": r"(education|academic|qualifications|degrees)",
        "skills": r"(skills|technical skills|competencies|technologies)",
        "certifications": r"(certifications|certificates|licenses)",
        "projects": r"(projects|portfolio|open source)",
        "languages": r"(languages|spoken languages)",
    }

    lines = raw_text.split("\n")
    sections: dict[str, list[str]] = {"_header": []}
    current_section = "_header"

    for line in lines:
        stripped = line.strip()
        if not stripped:
            sections.setdefault(current_section, []).append("")
            continue

        matched = False
        for section_key, pattern in section_headers.items():
            if re.match(pattern, stripped, re.IGNORECASE) and len(stripped) < 50:
                current_section = section_key
                sections.setdefault(current_section, [])
                matched = True
                break

        if not matched:
            sections.setdefault(current_section, []).append(line)

    return {k: "\n".join(v).strip() for k, v in sections.items() if v}


def extract_contact_info(raw_text: str) -> dict[str, str]:
    """Extract basic contact info via regex."""
    info = {}

    # Email
    email_match = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', raw_text)
    if email_match:
        info["email"] = email_match.group()

    # Phone
    phone_match = re.search(r'(\+?[\d\s\-\(\)]{10,})', raw_text)
    if phone_match:
        info["phone"] = phone_match.group().strip()

    # LinkedIn
    linkedin_match = re.search(r'linkedin\.com/in/[\w\-]+', raw_text, re.IGNORECASE)
    if linkedin_match:
        info["linkedin"] = "https://" + linkedin_match.group()

    # GitHub
    github_match = re.search(r'github\.com/[\w\-]+', raw_text, re.IGNORECASE)
    if github_match:
        info["github"] = "https://" + github_match.group()

    return info


def parse_cv(file_bytes: bytes, filename: str) -> dict[str, Any]:
    """
    Full CV parsing pipeline.
    Returns structured CV data ready for the Resume Agent.
    """
    raw_text = extract_text_from_file(file_bytes, filename)
    sections = parse_cv_sections(raw_text)
    contact_info = extract_contact_info(raw_text)

    return {
        "raw_text": raw_text,
        "sections": sections,
        "contact_info": contact_info,
        "word_count": len(raw_text.split()),
        "filename": filename,
    }
