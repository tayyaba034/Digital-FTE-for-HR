"""
tools/apify_scraper.py
Job scraping via Apify API with deduplication logic.
"""
import hashlib
import os
import re
from typing import Any
import httpx
import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

log = structlog.get_logger()

APIFY_BASE_URL = "https://api.apify.com/v2"

# Apify actor IDs for each platform
ACTORS = {
    "linkedin": "curious_coder/linkedin-jobs-scraper",
    "indeed": "misceres/indeed-scraper",
    "glassdoor": "bebity/glassdoor-jobs-scraper",
}


def _job_fingerprint(title: str, company: str) -> str:
    """Create a canonical ID for deduplication based on title + company."""
    normalized = f"{title.lower().strip()}|{company.lower().strip()}"
    normalized = re.sub(r'\s+', ' ', normalized)
    return hashlib.sha256(normalized.encode()).hexdigest()[:16]


def _deduplicate(jobs: list[dict]) -> tuple[list[dict], int]:
    """Remove duplicate jobs (same role at same company across platforms)."""
    seen: dict[str, dict] = {}
    for job in jobs:
        fp = _job_fingerprint(job["title"], job["company"])
        if fp not in seen:
            job["id"] = fp
            seen[fp] = job
        else:
            # Merge: keep the one with more info, add extra source
            existing = seen[fp]
            if "extra_sources" not in existing:
                existing["extra_sources"] = []
            existing["extra_sources"].append(job.get("source_platform"))
    
    duplicates_removed = len(jobs) - len(seen)
    return list(seen.values()), duplicates_removed


class ApifyScraper:
    def __init__(self):
        self.api_key = os.getenv("APIFY_API_KEY")
        if not self.api_key:
            log.warning("apify", status="APIFY_API_KEY not set — scraping will be mocked")

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def _run_actor(self, actor_id: str, input_data: dict) -> list[dict]:
        """Run an Apify actor and return results."""
        if not self.api_key:
            return self._mock_jobs(input_data.get("query", "Software Engineer"), actor_id)

        async with httpx.AsyncClient(timeout=120.0) as client:
            # Start run
            resp = await client.post(
                f"{APIFY_BASE_URL}/acts/{actor_id}/runs",
                params={"token": self.api_key},
                json=input_data
            )
            resp.raise_for_status()
            run_id = resp.json()["data"]["id"]
            log.info("apify.actor_started", actor=actor_id, run_id=run_id)

            # Wait for completion (poll)
            import asyncio
            for _ in range(60):  # max 5 min
                await asyncio.sleep(5)
                status_resp = await client.get(
                    f"{APIFY_BASE_URL}/actor-runs/{run_id}",
                    params={"token": self.api_key}
                )
                status = status_resp.json()["data"]["status"]
                if status == "SUCCEEDED":
                    break
                elif status in ("FAILED", "ABORTED", "TIMED-OUT"):
                    raise RuntimeError(f"Apify actor {actor_id} failed with status: {status}")

            # Fetch results
            results_resp = await client.get(
                f"{APIFY_BASE_URL}/actor-runs/{run_id}/dataset/items",
                params={"token": self.api_key, "format": "json"}
            )
            results_resp.raise_for_status()
            return results_resp.json()

    def _normalize_linkedin(self, raw: dict) -> dict:
        return {
            "title": raw.get("title", ""),
            "company": raw.get("companyName", ""),
            "location": raw.get("location", ""),
            "description": raw.get("description", ""),
            "source_url": raw.get("jobUrl", ""),
            "source_platform": "linkedin",
            "posted_date": raw.get("postedAt"),
            "salary_range": raw.get("salary"),
            "job_type": raw.get("contractType"),
            "requirements": [],
        }

    def _normalize_indeed(self, raw: dict) -> dict:
        return {
            "title": raw.get("positionName", ""),
            "company": raw.get("company", ""),
            "location": raw.get("location", ""),
            "description": raw.get("description", ""),
            "source_url": raw.get("url", ""),
            "source_platform": "indeed",
            "posted_date": raw.get("datePosted"),
            "salary_range": raw.get("salary"),
            "job_type": raw.get("jobType"),
            "requirements": [],
        }

    def _normalize_glassdoor(self, raw: dict) -> dict:
        return {
            "title": raw.get("jobTitle", ""),
            "company": raw.get("employer", {}).get("name", ""),
            "location": raw.get("location", ""),
            "description": raw.get("jobDescription", ""),
            "source_url": raw.get("jobListingUrl", ""),
            "source_platform": "glassdoor",
            "posted_date": raw.get("discoveredAt"),
            "salary_range": raw.get("estimatedSalary"),
            "job_type": raw.get("jobType"),
            "requirements": [],
        }

    def _mock_jobs(self, query: str, actor_id: str) -> list[dict]:
        """Return mock data when API key is not set (for development)."""
        platform = "linkedin" if "linkedin" in actor_id else "indeed" if "indeed" in actor_id else "glassdoor"
        return [
            {
                "title": f"Senior {query}",
                "company": f"TechCorp {platform.title()}",
                "location": "Remote / London, UK",
                "description": f"We are looking for a Senior {query} to join our growing team. "
                               "You will be responsible for designing scalable systems, "
                               "mentoring junior engineers, and shipping high-quality software.",
                "source_url": f"https://{platform}.com/jobs/mock-{platform}-1",
                "source_platform": platform,
                "salary_range": "£80,000 - £120,000",
                "job_type": "Full-time",
                "requirements": ["Python", "FastAPI", "PostgreSQL", "Docker", "AWS"],
            },
            {
                "title": f"Staff {query}",
                "company": f"StartupXYZ {platform.title()}",
                "location": "London, UK",
                "description": f"Join our mission-driven team as a Staff {query}. "
                               "We're building the next generation of developer tools.",
                "source_url": f"https://{platform}.com/jobs/mock-{platform}-2",
                "source_platform": platform,
                "salary_range": "£100,000 - £150,000",
                "job_type": "Full-time",
                "requirements": ["Python", "LangChain", "React", "PostgreSQL"],
            }
        ]

    async def scrape_jobs(
        self,
        query: str,
        locations: list[str],
        max_results: int = 50,
        platforms: list[str] | None = None,
    ) -> tuple[list[dict], int]:
        """
        Scrape jobs from multiple platforms and return deduplicated results.
        Returns: (jobs, duplicates_removed)
        """
        if platforms is None:
            platforms = ["linkedin", "indeed", "glassdoor"]

        all_raw: list[dict] = []

        for platform in platforms:
            actor_id = ACTORS.get(platform)
            if not actor_id:
                continue

            try:
                log.info("apify.scraping", platform=platform, query=query)

                if platform == "linkedin":
                    input_data = {
                        "keywords": query,
                        "location": locations[0] if locations else "United Kingdom",
                        "maxResults": max_results // len(platforms),
                    }
                    raw = await self._run_actor(actor_id, input_data)
                    normalized = [self._normalize_linkedin(r) for r in raw]

                elif platform == "indeed":
                    input_data = {
                        "query": query,
                        "location": locations[0] if locations else "United Kingdom",
                        "maxItems": max_results // len(platforms),
                    }
                    raw = await self._run_actor(actor_id, input_data)
                    normalized = [self._normalize_indeed(r) for r in raw]

                elif platform == "glassdoor":
                    input_data = {
                        "keyword": query,
                        "location": locations[0] if locations else "United Kingdom",
                        "maxItems": max_results // len(platforms),
                    }
                    raw = await self._run_actor(actor_id, input_data)
                    normalized = [self._normalize_glassdoor(r) for r in raw]

                else:
                    continue

                all_raw.extend(normalized)
                log.info("apify.scraped", platform=platform, count=len(normalized))

            except Exception as e:
                log.error("apify.scrape_error", platform=platform, error=str(e))

        jobs, duplicates_removed = _deduplicate(all_raw)
        log.info("apify.complete", total=len(jobs), duplicates_removed=duplicates_removed)
        return jobs, duplicates_removed
