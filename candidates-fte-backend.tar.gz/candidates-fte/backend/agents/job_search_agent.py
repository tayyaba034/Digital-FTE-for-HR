"""
agents/job_search_agent.py
Searches for jobs via Apify, deduplicates, and scores them against the user's profile.
"""
import uuid
from typing import Any
import structlog
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from memory.store import long_term, short_term
from observability.config import trace_agent
from schemas.models import AgentEvent
from tools.apify_scraper import ApifyScraper

log = structlog.get_logger()

JOB_MATCHING_PROMPT = """You are a job-matching expert. Given a user's profile and a list of job listings, 
score each job from 0.0 to 1.0 based on how well it matches the candidate.

User Profile:
{profile}

Jobs to score (return JSON array with job IDs and scores):
{jobs}

For each job, consider: skill overlap, experience level match, location preferences, salary range.
Return ONLY a JSON array like: [{"id": "abc123", "score": 0.87, "match_reasons": ["Python match", "Senior level"]}, ...]"""


class JobSearchAgent:
    def __init__(self, event_callback=None):
        self.llm = ChatAnthropic(model="claude-sonnet-4-6", temperature=0)
        self.scraper = ApifyScraper()
        self.event_callback = event_callback

    async def _emit(self, event_type: str, message: str, data: dict = {}):
        event = AgentEvent(event_type=event_type, agent_name="job_search_agent", message=message, data=data)
        log.info("job_search_agent.event", message=message)
        if self.event_callback:
            await self.event_callback(event)

    async def _score_jobs(self, jobs: list[dict], user_profile: dict) -> list[dict]:
        """Use Claude to score job matches."""
        if not jobs:
            return jobs

        # Slim down jobs for the prompt (save tokens)
        slim_jobs = [
            {"id": j["id"], "title": j["title"], "company": j["company"],
             "description": j.get("description", "")[:500],
             "requirements": j.get("requirements", [])}
            for j in jobs
        ]

        profile_summary = {
            "skills": user_profile.get("skills", []),
            "experience_years": user_profile.get("experience_years"),
            "target_roles": user_profile.get("target_roles", []),
            "location": user_profile.get("location"),
        }

        import json
        messages = [
            SystemMessage(content=JOB_MATCHING_PROMPT.format(
                profile=json.dumps(profile_summary),
                jobs=json.dumps(slim_jobs)
            ))
        ]

        try:
            response = await self.llm.ainvoke(messages)
            scores = json.loads(response.content)
            score_map = {s["id"]: s for s in scores}

            for job in jobs:
                match = score_map.get(job["id"], {})
                job["match_score"] = match.get("score", 0.5)
                job["match_reasons"] = match.get("match_reasons", [])

            # Sort by match score
            jobs.sort(key=lambda j: j.get("match_score", 0), reverse=True)
        except Exception as e:
            log.error("job_search_agent.scoring_error", error=str(e))

        return jobs

    @trace_agent("job_search_agent")
    async def run(
        self,
        user_id: str,
        workflow_id: str,
        role: str = "Software Engineer",
        locations: list[str] | None = None,
        max_results: int = 50,
    ) -> dict[str, Any]:
        """
        Full job search pipeline:
        1. Scrape jobs from multiple platforms
        2. Deduplicate
        3. Score against user profile
        4. Save to DB
        """
        locations = locations or ["Remote"]

        await self._emit("agent_progress", f"Searching for '{role}' jobs in {', '.join(locations)}...",
                        {"workflow_id": workflow_id})

        # 1. Scrape
        jobs, duplicates_removed = await self.scraper.scrape_jobs(
            query=role,
            locations=locations,
            max_results=max_results,
        )
        await self._emit("agent_progress", 
                        f"Found {len(jobs) + duplicates_removed} listings → {len(jobs)} unique after removing {duplicates_removed} duplicates",
                        {"workflow_id": workflow_id, "total_raw": len(jobs) + duplicates_removed,
                         "deduplicated": len(jobs), "removed": duplicates_removed})

        # 2. Load user profile for matching
        user_profile = await long_term.get_user_profile(user_id) or {}

        # 3. Score
        await self._emit("agent_progress", "Scoring job matches against your profile...", {"workflow_id": workflow_id})
        jobs = await self._score_jobs(jobs, user_profile)

        # 4. Save to DB
        await long_term.save_jobs(jobs, user_id)
        await short_term.set(f"jobs:{user_id}:latest", {"count": len(jobs), "workflow_id": workflow_id})

        await self._emit("agent_done",
                        f"✅ Saved {len(jobs)} jobs. Top match: {jobs[0]['title']} at {jobs[0]['company']} ({jobs[0].get('match_score', 0):.0%})" 
                        if jobs else "✅ Search complete (no results found)",
                        {"workflow_id": workflow_id})

        return {
            "total": len(jobs),
            "duplicates_removed": duplicates_removed,
            "top_jobs": jobs[:5],
        }
