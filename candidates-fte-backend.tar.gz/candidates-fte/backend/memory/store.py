"""
memory/store.py
Short-term memory (Redis) + Long-term memory (PostgreSQL).
"""
import json
import os
from datetime import datetime
from typing import Any, Optional
import asyncpg
import redis.asyncio as aioredis
import structlog

log = structlog.get_logger()

# ─────────────────────────────────────────────
# Short-term Memory — Redis
# ─────────────────────────────────────────────

class ShortTermMemory:
    """Redis-backed short-term memory for agent working state and sessions."""

    def __init__(self):
        self._client: aioredis.Redis | None = None

    async def connect(self):
        url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        self._client = await aioredis.from_url(url, decode_responses=True)
        log.info("memory.redis", status="connected", url=url)

    async def disconnect(self):
        if self._client:
            await self._client.aclose()

    @property
    def client(self) -> aioredis.Redis:
        if not self._client:
            raise RuntimeError("Redis not connected. Call connect() first.")
        return self._client

    async def set(self, key: str, value: Any, ttl: int = 3600):
        """Store a value. ttl in seconds (default 1h)."""
        data = json.dumps(value, default=str)
        await self.client.setex(key, ttl, data)

    async def get(self, key: str) -> Any | None:
        raw = await self.client.get(key)
        return json.loads(raw) if raw else None

    async def delete(self, key: str):
        await self.client.delete(key)

    async def append_to_list(self, key: str, value: Any, max_len: int = 100):
        """Append to a list (e.g., conversation history), trim to max_len."""
        data = json.dumps(value, default=str)
        await self.client.rpush(key, data)
        await self.client.ltrim(key, -max_len, -1)

    async def get_list(self, key: str) -> list[Any]:
        items = await self.client.lrange(key, 0, -1)
        return [json.loads(i) for i in items]

    # ── Workflow State ────────────────────────

    async def set_workflow_status(self, workflow_id: str, status: dict):
        await self.set(f"workflow:{workflow_id}", status, ttl=86400)

    async def get_workflow_status(self, workflow_id: str) -> dict | None:
        return await self.get(f"workflow:{workflow_id}")

    async def set_current_agent(self, workflow_id: str, agent_name: str | None):
        await self.set(f"workflow:{workflow_id}:current_agent", agent_name, ttl=86400)

    async def get_current_agent(self, workflow_id: str) -> str | None:
        return await self.get(f"workflow:{workflow_id}:current_agent")

    # ── Conversation History ──────────────────

    async def add_message(self, session_id: str, message: dict):
        await self.append_to_list(f"chat:{session_id}", message, max_len=200)

    async def get_messages(self, session_id: str) -> list[dict]:
        return await self.get_list(f"chat:{session_id}")

    # ── HITL Checkpoints ─────────────────────

    async def set_hitl_checkpoint(self, checkpoint_id: str, data: dict):
        await self.set(f"hitl:{checkpoint_id}", data, ttl=86400 * 7)

    async def get_hitl_checkpoint(self, checkpoint_id: str) -> dict | None:
        return await self.get(f"hitl:{checkpoint_id}")

    async def resolve_hitl_checkpoint(self, checkpoint_id: str, approved: bool):
        data = await self.get_hitl_checkpoint(checkpoint_id)
        if data:
            data["approved"] = approved
            data["resolved_at"] = datetime.utcnow().isoformat()
            await self.set(f"hitl:{checkpoint_id}", data, ttl=3600)


# ─────────────────────────────────────────────
# Long-term Memory — PostgreSQL
# ─────────────────────────────────────────────

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS user_profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES user_profiles(id),
    title TEXT NOT NULL,
    company TEXT NOT NULL,
    location TEXT,
    description TEXT,
    source_platform TEXT,
    source_url TEXT,
    match_score FLOAT DEFAULT 0,
    status TEXT DEFAULT 'fetched',
    hr_email TEXT,
    data JSONB NOT NULL DEFAULT '{}',
    fetched_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tailored_cvs (
    id TEXT PRIMARY KEY,
    job_id TEXT REFERENCES jobs(id),
    user_id TEXT REFERENCES user_profiles(id),
    content_markdown TEXT,
    content_html TEXT,
    ats_score FLOAT DEFAULT 0,
    status TEXT DEFAULT 'pending_approval',
    version INTEGER DEFAULT 1,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS email_drafts (
    id TEXT PRIMARY KEY,
    job_id TEXT REFERENCES jobs(id),
    cv_id TEXT REFERENCES tailored_cvs(id),
    user_id TEXT REFERENCES user_profiles(id),
    hr_email TEXT NOT NULL,
    subject TEXT,
    body TEXT,
    cover_letter TEXT,
    status TEXT DEFAULT 'pending_approval',
    sent_at TIMESTAMPTZ,
    data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS agent_traces (
    id TEXT PRIMARY KEY,
    workflow_id TEXT,
    agent_name TEXT,
    action TEXT,
    input_data JSONB,
    output_data JSONB,
    duration_ms INTEGER,
    status TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_jobs_user ON jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_cvs_job ON tailored_cvs(job_id);
CREATE INDEX IF NOT EXISTS idx_emails_status ON email_drafts(status);
CREATE INDEX IF NOT EXISTS idx_traces_workflow ON agent_traces(workflow_id);
"""


class LongTermMemory:
    """PostgreSQL-backed persistent memory."""

    def __init__(self):
        self._pool: asyncpg.Pool | None = None

    async def connect(self):
        url = os.getenv("POSTGRES_URL", "postgresql://postgres:password@localhost:5432/candidates_fte")
        # asyncpg uses postgresql:// not postgresql+asyncpg://
        url = url.replace("postgresql+asyncpg://", "postgresql://")
        self._pool = await asyncpg.create_pool(url, min_size=2, max_size=10)
        async with self._pool.acquire() as conn:
            await conn.execute(SCHEMA_SQL)
        log.info("memory.postgres", status="connected")

    async def disconnect(self):
        if self._pool:
            await self._pool.close()

    @property
    def pool(self) -> asyncpg.Pool:
        if not self._pool:
            raise RuntimeError("Postgres not connected. Call connect() first.")
        return self._pool

    # ── User Profile ──────────────────────────

    async def upsert_user_profile(self, profile: dict) -> dict:
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow(
                """INSERT INTO user_profiles (id, name, email, data)
                   VALUES ($1, $2, $3, $4)
                   ON CONFLICT (id) DO UPDATE
                   SET name=$2, email=$3, data=$4, updated_at=NOW()
                   RETURNING *""",
                profile["id"], profile["name"], profile["email"],
                json.dumps(profile)
            )
        return dict(row)

    async def get_user_profile(self, user_id: str) -> dict | None:
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM user_profiles WHERE id=$1", user_id)
        return dict(row) if row else None

    # ── Jobs ──────────────────────────────────

    async def save_jobs(self, jobs: list[dict], user_id: str):
        async with self.pool.acquire() as conn:
            await conn.executemany(
                """INSERT INTO jobs (id, user_id, title, company, location, description,
                   source_platform, source_url, match_score, status, hr_email, data)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
                   ON CONFLICT (id) DO UPDATE SET match_score=EXCLUDED.match_score,
                   status=EXCLUDED.status, data=EXCLUDED.data""",
                [(j["id"], user_id, j["title"], j["company"], j.get("location",""),
                  j.get("description",""), j["source_platform"], j["source_url"],
                  j.get("match_score", 0), j.get("status","fetched"),
                  j.get("hr_email"), json.dumps(j)) for j in jobs]
            )

    async def get_jobs(self, user_id: str, status: str | None = None) -> list[dict]:
        async with self.pool.acquire() as conn:
            if status:
                rows = await conn.fetch("SELECT * FROM jobs WHERE user_id=$1 AND status=$2 ORDER BY match_score DESC", user_id, status)
            else:
                rows = await conn.fetch("SELECT * FROM jobs WHERE user_id=$1 ORDER BY match_score DESC", user_id)
        return [dict(r) for r in rows]

    async def update_job_status(self, job_id: str, status: str, hr_email: str | None = None):
        async with self.pool.acquire() as conn:
            if hr_email:
                await conn.execute("UPDATE jobs SET status=$1, hr_email=$2 WHERE id=$3", status, hr_email, job_id)
            else:
                await conn.execute("UPDATE jobs SET status=$1 WHERE id=$2", status, job_id)

    # ── CVs ───────────────────────────────────

    async def save_cv(self, cv: dict, user_id: str):
        async with self.pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO tailored_cvs (id, job_id, user_id, content_markdown, content_html,
                   ats_score, status, version, data)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                   ON CONFLICT (id) DO UPDATE
                   SET content_markdown=$4, content_html=$5, ats_score=$6,
                   status=$7, version=$8, data=$9, updated_at=NOW()""",
                cv["id"], cv["job_id"], user_id, cv["content_markdown"],
                cv.get("content_html",""), cv.get("ats_score",0), cv.get("status","pending_approval"),
                cv.get("version",1), json.dumps(cv)
            )

    async def get_cvs(self, user_id: str, status: str | None = None) -> list[dict]:
        async with self.pool.acquire() as conn:
            if status:
                rows = await conn.fetch("SELECT * FROM tailored_cvs WHERE user_id=$1 AND status=$2", user_id, status)
            else:
                rows = await conn.fetch("SELECT * FROM tailored_cvs WHERE user_id=$1 ORDER BY created_at DESC", user_id)
        return [dict(r) for r in rows]

    async def update_cv_status(self, cv_id: str, status: str, content: dict | None = None):
        async with self.pool.acquire() as conn:
            if content:
                await conn.execute(
                    "UPDATE tailored_cvs SET status=$1, content_markdown=$2, content_html=$3, updated_at=NOW() WHERE id=$4",
                    status, content.get("markdown",""), content.get("html",""), cv_id
                )
            else:
                await conn.execute("UPDATE tailored_cvs SET status=$1, updated_at=NOW() WHERE id=$2", status, cv_id)

    # ── Email Drafts ──────────────────────────

    async def save_email_draft(self, draft: dict, user_id: str):
        async with self.pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO email_drafts (id, job_id, cv_id, user_id, hr_email, subject, body, cover_letter, status, data)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                   ON CONFLICT (id) DO UPDATE
                   SET subject=$6, body=$7, cover_letter=$8, status=$9, data=$10""",
                draft["id"], draft["job_id"], draft["cv_id"], user_id,
                draft["hr_email"], draft["subject"], draft["body"],
                draft["cover_letter"], draft.get("status","pending_approval"), json.dumps(draft)
            )

    async def get_email_drafts(self, user_id: str, status: str | None = None) -> list[dict]:
        async with self.pool.acquire() as conn:
            if status:
                rows = await conn.fetch("SELECT * FROM email_drafts WHERE user_id=$1 AND status=$2", user_id, status)
            else:
                rows = await conn.fetch("SELECT * FROM email_drafts WHERE user_id=$1 ORDER BY created_at DESC", user_id)
        return [dict(r) for r in rows]

    async def update_email_status(self, email_id: str, status: str, sent_at: datetime | None = None):
        async with self.pool.acquire() as conn:
            if sent_at:
                await conn.execute("UPDATE email_drafts SET status=$1, sent_at=$2 WHERE id=$3", status, sent_at, email_id)
            else:
                await conn.execute("UPDATE email_drafts SET status=$1 WHERE id=$2", status, email_id)

    # ── Agent Traces ──────────────────────────

    async def log_trace(self, trace: dict):
        async with self.pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO agent_traces (id, workflow_id, agent_name, action, input_data,
                   output_data, duration_ms, status)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8)""",
                trace["id"], trace.get("workflow_id"), trace["agent_name"],
                trace["action"], json.dumps(trace.get("input",{})),
                json.dumps(trace.get("output",{})), trace.get("duration_ms"),
                trace.get("status","ok")
            )

    async def get_traces(self, workflow_id: str) -> list[dict]:
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM agent_traces WHERE workflow_id=$1 ORDER BY created_at ASC", workflow_id
            )
        return [dict(r) for r in rows]


# ─────────────────────────────────────────────
# Singleton instances
# ─────────────────────────────────────────────

short_term = ShortTermMemory()
long_term = LongTermMemory()


async def init_memory():
    await short_term.connect()
    await long_term.connect()
    log.info("memory", status="all stores connected")


async def close_memory():
    await short_term.disconnect()
    await long_term.disconnect()
